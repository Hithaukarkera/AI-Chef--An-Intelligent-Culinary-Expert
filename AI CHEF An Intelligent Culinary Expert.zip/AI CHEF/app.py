from flask import Flask, render_template, request, redirect, url_for
import requests
from urllib.parse import unquote
import subprocess
import sys

app = Flask(__name__)

API_KEY = '84181c10fe794a2cb1f208759236f32c'

@app.route('/home', methods=['GET'])
def home():
    return render_template('index.html', recipes=[], search_query='')

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        query = request.form.get('search_query', '')
        recipes = search_recipes(query)
        return render_template('index.html', recipes=recipes, search_query=query)
    
    search_query = request.args.get('search_query', '')
    decoded_search_query = unquote(search_query)
    recipes = search_recipes(decoded_search_query)
    return render_template('index.html', recipes=recipes, search_query=decoded_search_query)

def search_recipes(query):
    url = f'https://api.spoonacular.com/recipes/complexSearch'
    params = {
        'apiKey': API_KEY,
        'query': query,
        'number': 10,
        'instructionsRequired': True,
        'addRecipeInformation': True,
        'fillIngredients': True,
    }

    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        return data['results']
    return []

@app.route('/recipe/<int:recipe_id>')
def view_recipe(recipe_id):
    search_query = request.args.get('search_query', '')
    url = f'https://api.spoonacular.com/recipes/{recipe_id}/information'
    params = {
        'apiKey': API_KEY,
    }

    response = requests.get(url, params=params)
    if response.status_code == 200:
        recipe = response.json()
        open_browser(recipe['sourceUrl'])  # Open recipe in default web browser
        return redirect(url_for('home'))  # Redirect to home page after opening the recipe
    return "Recipe not found", 404

def open_browser(url):
    if sys.platform.startswith('darwin'):
        subprocess.Popen(['open', url])
    elif sys.platform.startswith('win32'):
        subprocess.Popen(['start', url], shell=True)
    else:
        subprocess.Popen(['xdg-open', url])

open_browser("http://127.0.0.1:5000")  # Open browser when script starts

if __name__ == '__main__':
    app.run(debug=True)
