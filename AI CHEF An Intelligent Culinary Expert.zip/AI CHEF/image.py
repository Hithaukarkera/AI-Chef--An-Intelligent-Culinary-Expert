import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, Model
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, CSVLogger 


IMG_SIZE = (128, 128)
VALID_SPLIT = 0.3
BATCH_SIZE = 16
SEED = 42

PATH = r"C:\Users\Subra\Desktop\New folder (2)\New folder\food images"
train_ds = tf.keras.preprocessing.image_dataset_from_directory(
    PATH,
    validation_split=VALID_SPLIT,
    subset="training",
    seed=SEED,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="categorical"
)

val_ds = tf.keras.preprocessing.image_dataset_from_directory(
    PATH,
    validation_split=VALID_SPLIT,
    subset="validation",
    seed=SEED,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    label_mode="categorical"
)


classes = train_ds.class_names
print(classes)

# Data augmentation preprocessing
data_augmentation = keras.Sequential([
    layers.experimental.preprocessing.RandomFlip("horizontal_and_vertical"),
    layers.experimental.preprocessing.RandomRotation(0.2),
    layers.experimental.preprocessing.RandomZoom(0.2),
    layers.experimental.preprocessing.RandomContrast(0.2),
])


augmented_train_ds = train_ds.map(lambda x, y: (data_augmentation(x, training=True), y))
print(augmented_train_ds)
augmented_train_ds = augmented_train_ds.prefetch(buffer_size=32)
val_ds = val_ds.prefetch(buffer_size=32)

#RESNET50 model training
def make_model(input_shape, num_classes):
    base_model = ResNet50(weights='imagenet', include_top=False, input_shape=input_shape)
    x = base_model.output
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dense(1024, activation='relu')(x)
    predictions = layers.Dense(num_classes, activation='softmax')(x)
    model = Model(inputs=base_model.input, outputs=predictions)
    return model

print(IMG_SIZE + (3,))
model = make_model(input_shape=IMG_SIZE + (3,), num_classes=len(classes))

for layer in model.layers[:-10]:
    layer.trainable = False



model_path = 'my_model.h5'
model = tf.keras.models.load_model(model_path)



import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import ImageTk, Image
import numpy as np
import tensorflow as tf
import pandas as pd

model = tf.keras.models.load_model("my_model.h5")
csv_file = "Food_class.csv"
ingredient_data = pd.read_csv(csv_file)

IMG_SIZE = (128, 128)
classes = ['bhatura', 'bhindi_masala', 'biryani', 'burger', 'butter_naan', 'carrot_cake', 'chana_masala', 'chapati', 'chocolate_cake', 'club_sandwich', 'cup_cakes', 'dal_makhani', 'dal_tadka', 'dharwad_pedha', 'donuts', 'french_fries', 'fried_rice', 'gajar_ka_halwa', 'gulab_jamun', 'jalebi', 'kachori', 'kadai_paneer', 'kofta', 'lassi', 'modak', 'mysore_pak', 'naan', 'onion_rings', 'palak_paneer', 'pancakes', 'paneer_butter_masala', 'poha', 'rabri', 'ras_malai', 'rasgulla', 'samosa', 'sheera', 'sohan_papdi', 'unni_appam']  # Update with your actual class names

def predict_image():
    file_path = filedialog.askopenfilename()
    if file_path:
        try:
            raw_img = Image.open(file_path)
            raw_img = raw_img.resize(IMG_SIZE)
        except:
            messagebox.showerror("Error", "Failed to load the image!")
            return

        img_array = np.array(raw_img)

        img_array = np.expand_dims(img_array, 0)  
        img_array = tf.keras.applications.resnet50.preprocess_input(img_array)

        predictions = model.predict(img_array)
        pred_class_index = np.argmax(predictions)
        pred_class = classes[pred_class_index]

        ingredient_name = ingredient_data.loc[pred_class_index, 'ingredient_name']
        instruction_list = ingredient_data.loc[pred_class_index, 'instruction_list']
        nutritional_info = ingredient_data.loc[pred_class_index, 'nutritional_info']
        cooking_time = ingredient_data.loc[pred_class_index, 'cooking_time']

        top = tk.Toplevel()
        top.title("Prediction Result")

        label_img = tk.Label(top)
        label_img.pack(side=tk.LEFT, padx=10, pady=10)
        photo = ImageTk.PhotoImage(raw_img)
        label_img.config(image=photo)
        label_img.image = photo

        info_frame = tk.Frame(top)
        info_frame.pack(side=tk.LEFT, padx=10, pady=10)

        label_pred = tk.Label(info_frame, text=f"This image may be {pred_class}.\nIngredient: {ingredient_name}")
        label_pred.pack()

        instruction_text = tk.Text(info_frame, wrap="word", width=50, height=5) 
        instruction_text.insert(tk.END, f"Instruction: {instruction_list}")
        instruction_text.pack()

        nutritional_label = tk.Label(info_frame, text=f"Nutritional Info: {nutritional_info}")
        nutritional_label.pack()

        cooking_time_label = tk.Label(info_frame, text=f"Cooking Time: {cooking_time}")
        cooking_time_label.pack()
    else:
        messagebox.showerror("Error", "No image selected!")

root = tk.Tk()
root.title("Image Classifier")

btn_upload = tk.Button(root, text="Upload Image", command=predict_image)
btn_upload.pack(pady=20)

root.mainloop()




