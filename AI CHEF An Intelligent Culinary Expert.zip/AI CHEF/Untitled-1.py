from tkinter import *
from tkinter import ttk
import sqlite3
import tkinter.messagebox
import datetime
import os
import random
import re
import subprocess
date = datetime.datetime.now().date()
def show_frame(frame):
    frame.tkraise()


root = Tk()
root.geometry("1366x768+0+0")
root.title("KJ Mart-Store management System")
root.resizable(width=False, height=False)
root.rowconfigure(0, weight=1)
root.columnconfigure(0, weight=1)

def iui():
    subprocess.Popen(["python", "data_entry.py"])

def iui1():
    subprocess.Popen(["python", "app.py"])
    
def iui2():
    subprocess.Popen(["python", "image.py"])        

frame1 = tkinter.Frame(root)
frame2 = tkinter.Frame(root)
frame3 = tkinter.Frame(root)
frame4 = tkinter.Frame(root, bg="orange")

for frame in (frame1, frame2, frame3, frame4):
    frame.grid(row=0, column=0, sticky='nsew')
left = Frame(frame1, width=700, height=768, bg='floral white')
left.pack(side=LEFT)

right = Frame(frame1, width=666, height=768, bg='orange')
right.pack(side=RIGHT)

search_btn = Button(left, text="Feedback system", font=('arial 10 bold'), width=15, height=10, bg='green', fg="white", activebackground='white', activeforeground='black',command = iui)
search_btn1 = Button(left, text="Ingredient generator", font=('arial 10 bold'), width=15, height=10, bg='green', fg="white", activebackground='white', activeforeground='black',command = iui1)
search_btn2 = Button(left, text="Image recipe prediction", font=('arial 10 bold'), width=15, height=10, bg='green', fg="white", activebackground='white', activeforeground='black',command = iui2)
search_btn.place(x=60, y=80)
search_btn1.place(x=260, y=80)
search_btn2.place(x=460, y=80)

heading = Label(left, text="              AI CHEF", font=(
    'arial 40 bold'), bg='floral white')
heading.place(x=0, y=0)

date_label = Label(right, text="Today's Date: " +
                   str(date), font=('arial 16 bold'), bg='orange', fg='white')
date_label.place(x=0, y=0)

show_frame(frame1)
root.mainloop()