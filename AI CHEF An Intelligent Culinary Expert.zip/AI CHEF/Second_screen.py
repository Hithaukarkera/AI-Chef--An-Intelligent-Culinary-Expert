from pathlib import Path
import subprocess
from tkinter import Tk, Canvas, Entry, Text, Button, PhotoImage
OUTPUT_PATH = Path(__file__).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"C:\Users\Subra\Desktop\New folder (2)\tkinter designer op\build\assets\frame0")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)


window = Tk()

window.geometry("961x598")
window.configure(bg = "#FFC233")


canvas = Canvas(
    window,
    bg = "#FFC233",
    height = 598,
    width = 961,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge"
)

canvas.place(x = 0, y = 0)
image_image_1 = PhotoImage(
    file=relative_to_assets("image_1.png"))
image_1 = canvas.create_image(
    480.0,
    299.0,
    image=image_image_1
)

image_image_2 = PhotoImage(
    file=relative_to_assets("image_2.png"))
image_2 = canvas.create_image(
    482.0,
    113.0,
    image=image_image_2
)

def data():
    subprocess.Popen(["python","data_entry.py"])
button_image_1 = PhotoImage(
    file=relative_to_assets("button_1.png"))
button_1 = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=data,
    relief="flat"
)
button_1.place(
    x=65.0,
    y=401.0,
    width=418.0,
    height=86.0
)
def generator():
    subprocess.Popen(["python","app.py"])

button_image_2 = PhotoImage(
    file=relative_to_assets("button_2.png"))
button_2 = Button(
    image=button_image_2,
    borderwidth=0,
    highlightthickness=0,
    command=generator,
    relief="flat"
)
button_2.place(
    x=62.0,
    y=213.0,
    width=419.0,
    height=86.0
)
def imagegenarator():
    subprocess.Popen(["python","image.py"])

button_image_3 = PhotoImage(
    file=relative_to_assets("button_3.png"))
button_3 = Button(
    image=button_image_3,
    borderwidth=0,
    highlightthickness=0,
    command=imagegenarator,
    relief="flat"
)
button_3.place(
    x=65.0,
    y=307.0,
    width=417.0,
    height=86.0
)

image_image_3 = PhotoImage(
    file=relative_to_assets("image_3.png"))
image_3 = canvas.create_image(
    709.0,
    351.0,
    image=image_image_3
)

canvas.create_text(
    0.0,
    523.0,
    anchor="nw",
    text="                                                            An Intelligent culinary expert",
    fill="#FFFFFF",
    font=("Inter", 20 * -1)
)

canvas.create_rectangle(
    -7.0,
    499.0,
    960.998876758611,
    513.1563744922896,
    fill="#FFFFFF",
    outline="")
window.resizable(False, False)
window.mainloop()
